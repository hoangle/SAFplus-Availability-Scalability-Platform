/* Generated automatically. */
static const char configuration_arguments[] = "/home/mrv/toolchain/.build/src/gcc-4.6.3/configure --build=i686-build_pc-linux-gnu --host=i686-build_pc-linux-gnu --target=i686-nptl-linux-gnu --prefix=/home/mrv/buildtools/i686-nptl-linux-gnu --with-sysroot=/home/mrv/buildtools/i686-nptl-linux-gnu/i686-nptl-linux-gnu/sysroot --enable-languages=c,c++ --with-arch=i686 --with-pkgversion='crosstool-NG 1.18.0' --enable-__cxa_atexit --disable-libmudflap --disable-libgomp --disable-libssp --disable-libquadmath --disable-libquadmath-support --with-gmp=/home/mrv/toolchain/.build/i686-nptl-linux-gnu/buildtools --with-mpfr=/home/mrv/toolchain/.build/i686-nptl-linux-gnu/buildtools --with-mpc=/home/mrv/toolchain/.build/i686-nptl-linux-gnu/buildtools --with-ppl=no --with-cloog=no --with-libelf=/home/mrv/toolchain/.build/i686-nptl-linux-gnu/buildtools --with-host-libstdcxx='-static-libgcc -Wl,-Bstatic,-lstdc++,-Bdynamic -lm' --enable-threads=posix --enable-target-optspace --enable-plugin --disable-nls --disable-multilib --with-local-prefix=/home/mrv/buildtools/i686-nptl-linux-gnu/i686-nptl-linux-gnu/sysroot --enable-c99 --enable-long-long";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "i686" } };
